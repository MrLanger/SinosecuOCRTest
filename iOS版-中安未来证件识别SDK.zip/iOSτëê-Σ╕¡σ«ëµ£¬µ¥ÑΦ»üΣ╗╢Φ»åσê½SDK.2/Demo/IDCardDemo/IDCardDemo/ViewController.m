//
//  ViewController.m
//  IDCardDemo
//

#import "ViewController.h"
#import "ResultViewController.h"
#import "IDCardCameraViewController.h"


#if TARGET_IPHONE_SIMULATOR//simulator
#elif TARGET_OS_IPHONE//device
#import "IDCardOCR.h"
#endif

@interface ViewController ()<UIActionSheetDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    NSString *_originalImagepath;
    NSString *_cropImagepath;
    NSString *_headImagePath;
    NSDictionary *_IDTypeDic;
}

@property (strong, nonatomic) NSMutableArray *types;

@property (assign, nonatomic) int cardType;

@property (assign, nonatomic) int resultCount;

@property (strong, nonatomic) NSString *typeName;

#if TARGET_IPHONE_SIMULATOR//simulator
#elif TARGET_OS_IPHONE//device
@property (strong, nonatomic) IDCardOCR *cardRecog;
#endif


@end

@implementation ViewController

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = paths[0];
    _originalImagepath = [documentsDirectory stringByAppendingPathComponent:@"originalImage.jpg"];
    _cropImagepath = [documentsDirectory stringByAppendingPathComponent:@"cropImage.jpg"];
    _headImagePath = [documentsDirectory stringByAppendingPathComponent:@"headImage.jpg"];
    
    [self setCardTypes];
    
    self.cardType = 2;
    self.typeName = NSLocalizedString(@"Chinese ID card", nil) ;
}

- (void)setCardTypes{
    
    _IDTypeDic =@{
                  @1:NSLocalizedString(@"Frist Chinese ID card", nil),
                  @2:NSLocalizedString(@"Chinese ID card", nil),
                  @4:NSLocalizedString(@"Temporary Chinese ID card", nil),
                  @5:NSLocalizedString(@"Chinese Driving license", nil),
                  @28:NSLocalizedString(@"Chinese Driving license(second)", nil),
                  @6:NSLocalizedString(@"Chinese vehicle license", nil),
                  @7:NSLocalizedString(@"Chinese certificate of officers", nil),
                  @9:NSLocalizedString(@"Exit-Entry Permit to HK/Macau", nil),
                  @22:NSLocalizedString(@"e-EEP to HK/Macau", nil),
                  @10:NSLocalizedString(@"To the Mainland Travel Permit", nil),
                  @11:NSLocalizedString(@"Taiwan pass", nil),
                  @12:NSLocalizedString(@"Visa", nil),
                  @13:NSLocalizedString(@"Passport", nil),
                  @14:NSLocalizedString(@"Home return permit (Obverse)", nil),
                  @15:NSLocalizedString(@"Home return permit (Reverse)", nil),
                  @16:NSLocalizedString(@"Household Register", nil),
                  @1000:NSLocalizedString(@"Residence Permit", nil),
                  @1001:NSLocalizedString(@"HK ID card", nil),
                  @1005:NSLocalizedString(@"Macau ID card", nil),
                  @1012:NSLocalizedString(@"New Macau ID card", nil),
                  @1007:NSLocalizedString(@"Awyer Qualification Certificate（A）", nil),
                  @1008:NSLocalizedString(@"Awyer Qualification Certificate（B）", nil),
                  @1009:NSLocalizedString(@"Road Transport Certificate IC", nil),
                  @3000:NSLocalizedString(@"Machine readable zone", nil),
                  @1030:NSLocalizedString(@"National health care card", nil),
                  @1031:NSLocalizedString(@"Taiwan ID card (Obverse)", nil),
                  @1032:NSLocalizedString(@"Taiwan ID card (Reverse)", nil),
                  @2001:NSLocalizedString(@"MyKad", nil),
                  @2002:NSLocalizedString(@"California driving license", nil),
                  @2003:NSLocalizedString(@"New Zealand Driving license", nil),
                  @2004:NSLocalizedString(@"Singapore ID card", nil),

                  @25:NSLocalizedString(@"To the New Mainland Travel Permit(Obverse)", nil),
                  @26:NSLocalizedString(@"To the New Mainland Travel Permit(Reverse)", nil),
                  @2010:NSLocalizedString(@"Indonesia Identity Card", nil),
                  @2011:NSLocalizedString(@"Thailand's Identity Card", nil),
                  @1021:NSLocalizedString(@"Beijing social security card", nil),

                  };
}

//Select Document Type
- (IBAction)selectCardType:(id)sender{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] init];
    actionSheet.delegate = self;
    actionSheet.title = NSLocalizedString(@"Select Document Type", nil);
    
    for (NSString *str in [_IDTypeDic allValues]) {
        [actionSheet addButtonWithTitle:str];
    }
    [actionSheet addButtonWithTitle:NSLocalizedString(@"Cancle", nil)];
    actionSheet.cancelButtonIndex = [[_IDTypeDic allKeys] count];
    [actionSheet showInView:self.view];
    
}
#pragma mark - UIActionSheetDelegate
- (void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        return;
    }
    self.cardType = [[[_IDTypeDic allKeys] objectAtIndex:buttonIndex] intValue];
    self.typeName = [[_IDTypeDic allValues] objectAtIndex:buttonIndex];
}

- (IBAction)scanningInHorizontalScreen:(id)sender{
    [self initCameraWithRecogOrientation:RecogInHorizontalScreen CropType:0];
}
- (IBAction)scanningInVerticalScreen:(id)sender{
    [self initCameraWithRecogOrientation:RecogInVerticalScreen CropType:0];
}
- (IBAction)scanningIntelligent:(id)sender {
    [self initCameraWithRecogOrientation:RecogInHorizontalScreen CropType:1];
}

- (void) initCameraWithRecogOrientation: (int)recogOrientation CropType:(int)cropType{
    IDCardCameraViewController *cameraVC = [[IDCardCameraViewController alloc] init];
    cameraVC.recogType = self.cardType;
    cameraVC.typeName = self.typeName;
    cameraVC.cropType = cropType;
    cameraVC.recogOrientation = recogOrientation;
    [self.navigationController pushViewController:cameraVC animated:YES];
}

- (IBAction)selectToRecog:(id)sender{
    
    UIImagePickerControllerSourceType sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
    UIImagePickerController * picker = [[UIImagePickerController alloc]init];
    picker.delegate = self;
    picker.allowsEditing=YES;
    picker.sourceType=sourceType;
    [self presentViewController:picker animated:YES completion:nil];
}

-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage * image=[info objectForKey:UIImagePickerControllerOriginalImage];
    [self performSelectorInBackground:@selector(didFinishedSelect:) withObject:image];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

-(void)didFinishedSelect:(UIImage *)image{
    [UIImageJPEGRepresentation(image, 1.0f) writeToFile:_originalImagepath atomically:YES];
    NSLog(@"_originalImagepath= %@",_originalImagepath);
    [self performSelectorInBackground:@selector(recog) withObject:nil];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController*)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#if TARGET_IPHONE_SIMULATOR//simulator

#elif TARGET_OS_IPHONE//device
// Initialize the recognition core
- (void) initRecog
{
    NSDate *before = [NSDate date];
    
    /*Acquire system language, load Chinese templates under Chinese system environment, and load English templates under non-Chinese system environment.
     Under English template, the field name is in English. For example, for Chinese field name “姓名”, the responsible English template is “Name”*/
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];
    int initLanguages;
    NSString * preferredLang = [allLanguages objectAtIndex:0];
    if ([preferredLang rangeOfString:@"zh"].length > 0) {
        initLanguages = 0;
    }else{
        initLanguages = 3;
    }
    self.cardRecog = [[IDCardOCR alloc] init];
    /*Notice: This development code and the authorization under this project is just used for demo and please replace the  code and .lsc file under Copy Bundle Resources */
    int intRecog = [self.cardRecog InitIDCardWithDevcode:kDevcode recogLanguage:initLanguages];
    NSLog(@"intRecog = %d\ncoreVersion = %@",intRecog,[self.cardRecog getCoreVersion]);
    NSTimeInterval time = [[NSDate date] timeIntervalSinceDate:before];
    NSLog(@"%f", time);
}

- (void)recog{
    // Initialize the recognition core
    [self initRecog];
    
    //close rejection
    [self.cardRecog setIDCardRejectType:self.cardType isSet:false];
    
    //set parameter and card type
    [self.cardRecog setParameterWithMode:0 CardType:self.cardType];
    //image pretreatment
    [self.cardRecog processImageWithProcessType:7 setType:1];
    
    //load image
    int loadImage = [self.cardRecog LoadImageToMemoryWithFileName:_originalImagepath Type:0];
    NSLog(@"loadImage = %d", loadImage);
    if (self.cardType != 3000) {
        if (self.cardType == 2) {
            
            // determine the reverse and obverse sides of Chinese second-generation ID card
            [self.cardRecog autoRecogChineseID];

        }else{
            // recognize documents without MRZ
            int recog = [self.cardRecog recogIDCardWithMainID:self.cardType];
            NSLog(@"recog = %d",recog);
        }
        // save the cut image to headImagePath
        [self.cardRecog saveHeaderImage:_headImagePath];
        
        
        // save the cut full image to imagepath
        [self.cardRecog saveImage:_cropImagepath];
        NSString *allResult = @"";
        for (int i = 1; i < 25; i++) {

            // acquire fields value
            NSString *field = [self.cardRecog GetFieldNameWithIndex:i];
            // acquire fields result
            NSString *result = [self.cardRecog GetRecogResultWithIndex:i];
            NSLog(@"%@:%@\n",field, result);
            if(field != NULL){
                allResult = [allResult stringByAppendingString:[NSString stringWithFormat:@"%@:%@\n", field, result]];
            }
        }
        if (![allResult isEqualToString:@""]) {
            
            //free initialize the recognition core
            [self.cardRecog recogFree];
            
            //jump to the result page
            [self performSelectorOnMainThread:@selector(createResultView:) withObject:allResult waitUntilDone:YES];
        }else{
        }
    }
}

#endif
- (void)createResultView:(NSString *)allResult{
    ResultViewController *rvc = [[ResultViewController alloc] initWithNibName:@"ResultViewController" bundle:nil];
    NSLog(@"allresult = %@", allResult);
    rvc.resultString = allResult;
    rvc.cropImagepath = _cropImagepath;
    rvc.headImagepath = _headImagePath;
    rvc.originalImagepath = _originalImagepath;
    rvc.typeName = self.typeName;
    [self.navigationController pushViewController:rvc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
