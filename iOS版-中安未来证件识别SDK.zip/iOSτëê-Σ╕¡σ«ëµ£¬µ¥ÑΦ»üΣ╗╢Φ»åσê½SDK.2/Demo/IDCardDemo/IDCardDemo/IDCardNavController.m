//
//  WTNavController.m
//  IDCardDemo
//

#import "IDCardNavController.h"
//#import "IDCardCameraViewController.h"
#import "IDCardCameraViewController.h"
@interface IDCardNavController ()

@end

@implementation IDCardNavController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

//- (BOOL)shouldAutorotate {
//    
//    NSArray *viewControllers = self.viewControllers;
//    for (UIViewController *viewController in viewControllers) {
//        if ([viewController isKindOfClass:[IDCardCameraViewController class]]) {
//            return NO;
//        }
//    }
//    return YES;
//}

@end
