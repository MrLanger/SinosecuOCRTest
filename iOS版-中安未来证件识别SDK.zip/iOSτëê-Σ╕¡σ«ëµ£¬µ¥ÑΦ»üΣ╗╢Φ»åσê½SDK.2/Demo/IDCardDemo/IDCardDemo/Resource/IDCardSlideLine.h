//
//  SlideLine.h
//

#import <Foundation/Foundation.h>

@interface IDCardSlideLine : NSObject

@property (assign, nonatomic) int allLine;
@property (assign, nonatomic) int leftLine;
@property (assign, nonatomic) int rightLine;
@property (assign, nonatomic) int topLine;
@property (assign, nonatomic) int bottomLine;

@end
