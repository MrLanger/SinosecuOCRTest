//
//  WTNavController.h
//  BankCardRecogDemo
//

#import <UIKit/UIKit.h>

@interface IDCardNavController : UINavigationController

@end
